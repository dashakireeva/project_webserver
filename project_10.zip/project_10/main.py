from flask import Flask, session, redirect
from data import db_session
from data.users import User
from data.my_heroes import My_heroes
from flask import Flask, render_template, request, make_response
from forms.user import RegisterForm_01, LoginForm
from forms.my_heroes import HeroesForm
from flask_login import login_user, login_required, logout_user, current_user   
import datetime
from flask_login import LoginManager
from data import db_session, my_heroes_api
from flask import jsonify


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
app.config['PERMANENT_SESSION_LIFETIME'] = datetime.timedelta(days=365)
db_session.global_init("db/blogs.db")
login_manager = LoginManager()
login_manager.init_app(app)


@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Not found'}), 404)


@app.route('/my_heroes_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def my_heroes_delete(id):
    db_sess = db_session.create_session()
    my_heroes = db_sess.query(My_heroes).filter(My_heroes.id == id,
                                      My_heroes.user == current_user
                                      ).first()
    if my_heroes:
        db_sess.delete(my_heroes)
        db_sess.commit()
    else:
        abort(404)
    return redirect('/')


@app.route('/all_news/<int:id>', methods=['GET', 'POST'])
@login_required
def all_news(id):
    db_sess = db_session.create_session()
    if current_user.is_authenticated:
        my_heroes = db_sess.query(My_heroes).filter(((My_heroes.user == current_user) | (My_heroes.is_private != True)), (My_heroes.id) == id)
    else:
        my_heroes = db_sess.query(My_heroes).filter(My_heroes.is_private != True, (My_heroes.id) == id)
    res = make_response(render_template("index1.html", my_heroes=my_heroes))
    res.set_cookie("visits_count", '1', max_age=60 * 60 * 24 * 365 * 2)
    return res




@app.route('/my_heroes/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_my_heroes(id):
    form = HeroesForm()
    if request.method == "GET":
        db_sess = db_session.create_session()
        my_heroes = db_sess.query(My_heroes).filter(My_heroes.id == id,
                                          My_heroes.user == current_user
                                          ).first()
        if my_heroes:
            form.title.data = my_heroes.title
            form.dates_of_birth.data = my_heroes.dates_of_birth
            form.dates_of_death.data = my_heroes.dates_of_death
            form.place_of_birth.data = my_heroes.place_of_birth
            form.place_of_death.data = my_heroes.place_of_death
            form.spouse.data = my_heroes.spouse
            form.wedding.data = my_heroes.wedding
            form.father.data = my_heroes.father
            form.mother.data = my_heroes.mother
            form.sons.data = my_heroes.sons
            form.daughters.data = my_heroes.daughters
            form.brothers.data = my_heroes.brothers
            form.sisters.data = my_heroes.sisters
            form.obrazavanie.data = my_heroes.obrazavanie
            form.work.data = my_heroes.work
            form.before_wwii.data = my_heroes.before_wwii
            form.second_world_war.data = my_heroes.second_world_war
            form.in_wwii.data = my_heroes.in_wwii
            form.content.data = my_heroes.content
            form.note_01.data = my_heroes.note_01
            form.note_02.data = my_heroes.note_02
            form.note_03.data = my_heroes.note_03
            form.is_private.data = my_heroes.is_private
        else:
            abort(404)
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        my_heroes = db_sess.query(My_heroes).filter(My_heroes.id == id,
                                          My_heroes.user == current_user
                                          ).first()
        if my_heroes:
            my_heroes.title = form.title.data
            my_heroes.dates_of_birth = form.dates_of_birth.data
            my_heroes.dates_of_death = form.dates_of_death.data
            my_heroes.place_of_birth = form.place_of_birth.data
            my_heroes.place_of_death = form.place_of_death.data
            my_heroes.spouse = form.spouse.data
            my_heroes.wedding = form.wedding.data
            my_heroes.father = form.father.data
            my_heroes.mother = form.mother.data
            my_heroes.sons = form.sons.data
            my_heroes.daughters = form.daughters.data
            my_heroes.brothers = form.brothers.data
            my_heroes.sisters = form.sisters.data 
            my_heroes.obrazavanie = form.obrazavanie.data
            my_heroes.work = form.work.data
            my_heroes.before_wwii = form.before_wwii.data
            my_heroes.second_world_war = form.second_world_war.data
            my_heroes.in_wwii = form.in_wwii.data
            my_heroes.content = form.content.data
            my_heroes.note_01 = form.note_01.data
            my_heroes.note_02 = form.note_02.data
            my_heroes.note_03 = form.note_03.data
            my_heroes.is_private = form.is_private.data
            db_sess.commit()
            return redirect('/')
        else:
            abort(404)
    return render_template('My_heroes.html',
                           title='Редактирование новости',
                           form=form
                           )


@app.route('/my_heroes_expand/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_my_heroes_expand(id):
    form = HeroesForm()
    if request.method == "GET":
        db_sess = db_session.create_session()
        my_heroes = db_sess.query(My_heroes).filter(My_heroes.id == id,
                                          My_heroes.user == current_user
                                          ).first()
        if my_heroes:
            form.title.data = my_heroes.title
            form.dates_of_birth.data = my_heroes.dates_of_birth
            form.dates_of_death.data = my_heroes.dates_of_death
            form.place_of_birth.data = my_heroes.place_of_birth
            form.place_of_death.data = my_heroes.place_of_death
            form.spouse.data = my_heroes.spouse
            form.wedding.data = my_heroes.wedding
            form.father.data = my_heroes.father
            form.mother.data = my_heroes.mother
            form.sons.data = my_heroes.sons
            form.daughters.data = my_heroes.daughters
            form.brothers.data = my_heroes.brothers
            form.sisters.data = my_heroes.sisters
            form.obrazavanie.data = my_heroes.obrazavanie
            form.work.data = my_heroes.work
            form.before_wwii.data = my_heroes.before_wwii
            form.second_world_war.data = my_heroes.second_world_war
            form.in_wwii.data = my_heroes.in_wwii
            form.content.data = my_heroes.content
            form.note_01.data = my_heroes.note_01
            form.note_02.data = my_heroes.note_02
            form.note_03.data = my_heroes.note_03
            form.is_private.data = my_heroes.is_private
        else:
            abort(404)
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        my_heroes = db_sess.query(My_heroes).filter(My_heroes.id == id,
                                          My_heroes.user == current_user
                                          ).first()
        if my_heroes:
            my_heroes.title = form.title.data
            my_heroes.dates_of_birth = form.dates_of_birth.datф
            my_heroes.dates_of_death = form.dates_of_death.data 
            my_heroes.place_of_birth = form.place_of_birth.data
            my_heroes.place_of_death = form.place_of_death.data
            my_heroes.spouse = form.spouse.data
            my_heroes.wedding = form.wedding.data
            my_heroes.father = form.father.data
            my_heroes.mother = form.mother.data
            my_heroes.sons = form.sons.data
            my_heroes.daughters = form.daughters.data
            my_heroes.brothers = form.brothers.data
            my_heroes.sisters = form.sisters.data 
            my_heroes.obrazavanie = form.obrazavanie.data
            my_heroes.work = form.work.data
            my_heroes.before_wwii = form.before_wwii.data
            my_heroes.second_world_war = form.second_world_war.data
            my_heroes.in_wwii = form.in_wwii.data
            my_heroes.content = form.content.data
            my_heroes.note_01 = form.note_01.data
            my_heroes.note_02 = form.note_02.data
            my_heroes.note_03 = form.note_03.data
            my_heroes.is_private = form.is_private.data
            db_sess.commit()
            return redirect('/')
        else:
            abort(404)
    return render_template('my_heroes.html',
                           title='Редактирование страницы героя',
                           form=form
                           )



@app.route('/my_heroes',  methods=['GET', 'POST'])
@login_required
def add_my_heroes():
    form = HeroesForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        my_heroes = My_heroes()
        my_heroes.title = form.title.data
        my_heroes.dates_of_birth = form.dates_of_birth.data
        my_heroes.dates_of_death = form.dates_of_death.data
        my_heroes.place_of_birth = form.place_of_birth.data
        my_heroes.place_of_death = form.place_of_death.data
        my_heroes.spouse = form.spouse.data
        my_heroes.wedding = form.wedding.data
        my_heroes.father = form.father.data
        my_heroes.mother = form.mother.data
        my_heroes.sons = form.sons.data
        my_heroes.daughters = form.daughters.data
        my_heroes.brothers = form.brothers.data
        my_heroes.sisters = form.sisters.data 
        my_heroes.obrazavanie = form.obrazavanie.data
        my_heroes.work = form.work.data
        my_heroes.before_wwii = form.before_wwii.data
        my_heroes.second_world_war = form.second_world_war.data
        my_heroes.in_wwii = form.in_wwii.data
        my_heroes.content = form.content.data
        my_heroes.note_01 = form.note_01.data
        my_heroes.note_02 = form.note_02.data
        my_heroes.note_03 = form.note_03.data
        my_heroes.is_private = form.is_private.data
        current_user.my_heroes.append(my_heroes)
        db_sess.merge(current_user)
        db_sess.commit()
        return redirect('/')
    return render_template('my_heroes.html', title='Добавление героя', 
                           form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)



@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)



# @app.route("/session_test")
# def session_test():
#     visits_count = session.get('visits_count', 0)
#     session['visits_count'] = visits_count + 1
#     return make_response(
#         f"Вы пришли на эту страницу {visits_count + 1} раз")



# @app.route("/cookie_test")
# def cookie_test():
#     visits_count = int(request.cookies.get("visits_count", 0))
#     if visits_count:
#         res = make_response(
#             f"Вы пришли на эту страницу {visits_count + 1} раз")
#         res.set_cookie("visits_count", str(visits_count + 1),
#                        max_age=60 * 60 * 24 * 365 * 2)
#     else:
#         res = make_response(
#             "Вы пришли на эту страницу в первый раз за последние 2 года")
#         res.set_cookie("visits_count", '1',
#                        max_age=60 * 60 * 24 * 365 * 2)
#     return res


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm_01()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            name=form.name.data,
            email=form.email.data,
            about=form.about.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


@app.route("/")
def index():
    db_sess = db_session.create_session()
    if current_user.is_authenticated:
        my_heroes = db_sess.query(My_heroes).filter((My_heroes.user == current_user) | (My_heroes.is_private != True))
    else:
        my_heroes = db_sess.query(My_heroes).filter(My_heroes.is_private != True)
    res = make_response(render_template("index.html", my_heroes=my_heroes))
    res.set_cookie("visits_count", '1', max_age=60 * 60 * 24 * 365 * 2)
    return res


def main():
    db_session.global_init("db/blogs.db")
    app.register_blueprint(my_heroes_api.blueprint)
    app.run()


if __name__ == '__main__':
    main()

