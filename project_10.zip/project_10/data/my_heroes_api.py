import flask
from flask import jsonify, request
from . import db_session
from .my_heroes import My_heroes


blueprint = flask.Blueprint(
    'my_heroes_api',
    __name__,
    template_folder='templates')


@blueprint.route('/api/my_heroes')
def get_my_heroes():
    db_sess = db_session.create_session()
    my_heroes = db_sess.query(My_heroes).all()
    return jsonify(
        {
            'my_heroes':
                [item.to_dict(only=('title', 'content', 'user.name')) 
                 for item in my_heroes]
        }
    )



@blueprint.route('/api/my_heroes', methods=['POST'])
def create_my_heroes():
    if not request.json:
        return jsonify({'error': 'Empty request'})
    elif not all(key in request.json for key in
                 ['title', 'dates_of_birth', 'dates_of_death', 
                 'place_of_birth', 'place_of_death',
                 'spouse', 'wedding', 'father', 'mother',
                 'sons', 'daughters', 'brothers',
                 'sisters', 'obrazavanie', 'work',
                 'before_wwii', 'second_world_war', 'in_wwii', 
                 'content', 'note_01', 'note_02', 'note_03',
                 'user_id', 'is_private']):
        return jsonify({'error': 'Bad request'})
    db_sess = db_session.create_session()
    my_heroes = My_heroes(
        title=request.json['title'],
        dates_of_birth=request.json['dates_of_birth'],
        dates_of_death=request.json['dates_of_death'],
        place_of_birth=request.json['place_of_birth'],
        place_of_death=request.json['place_of_death'],
        spouse=request.json['spouse'],
        wedding=request.json['wedding'],
        father=request.json['father'],
        mother=request.json['mother'],
        sons=request.json['sons'],
        daughters=request.json['daughters'],
        brothers=request.json['brothers'],
        sisters=request.json['sisters'],
        obrazavanie=request.json['obrazavanie'],
        work=request.json['work'],
        before_wwii=request.json['before_wwii'],
        second_world_war=request.json['second_world_war'],
        in_wwii=request.json['in_wwii'],
        content=request.json['content'],
        note_01=request.json['note_01'],
        note_02=request.json['note_02'],
        note_03=request.json['note_03'],
        user_id=request.json['user_id'],
        is_private=request.json['is_private']
    )
    db_sess.add(my_heroes)
    db_sess.commit()
    return jsonify({'success': 'OK'})


@blueprint.route('/api/my_heroes/<int:my_heroes_id>', methods=['GET'])
def get_one_my_heroes(my_heroes_id):
    db_sess = db_session.create_session()
    my_heroes = db_sess.query(My_heroes).get(my_heroes_id)
    if not my_heroes:
        return jsonify({'error': 'Not found1'})
    return jsonify(
        {
            'my_heroes': my_heroes.to_dict(only=(
                'title', 'dates_of_birth', 'dates_of_death', 
                 'place_of_birth', 'place_of_death',
                 'spouse', 'wedding', 'father', 'mother',
                 'sons', 'daughters', 'brothers',
                 'sisters', 'obrazavanie', 'work',
                 'before_wwii', 'second_world_war', 'in_wwii', 
                 'content', 'note_01', 'note_02', 'note_03',
                 'user_id', 'is_private'))
        }
    )


@blueprint.route('/api/my_heroes/<int:my_heroes_id>', methods=['DELETE'])
def delete_my_heroes(my_heroes_id):
    db_sess = db_session.create_session()
    my_heroes = db_sess.query(My_heroes).get(My_heroes_id)
    if not my_heroes:
        return jsonify({'error': 'Not found2'})
    db_sess.delete(my_heroes)
    db_sess.commit()
    return jsonify({'success': 'OK'})


