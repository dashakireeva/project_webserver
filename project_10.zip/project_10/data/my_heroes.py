import datetime
import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase
from sqlalchemy_serializer import SerializerMixin



class My_heroes(SqlAlchemyBase, SerializerMixin):
    __tablename__ = 'my_heroes'

    id = sqlalchemy.Column(sqlalchemy.Integer, 
                           primary_key=True, autoincrement=True)
    title = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    dates_of_birth = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    dates_of_death = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    place_of_birth = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    place_of_death = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    spouse = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    wedding = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    father = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    mother = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    sons = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    daughters = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    brothers = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    sisters = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    obrazavanie = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    work = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    before_wwii = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    second_world_war = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    in_wwii = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    content = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    note_01 = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    note_02 = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    note_03 = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    created_date = sqlalchemy.Column(sqlalchemy.DateTime, 
                                     default=datetime.datetime.now)
    is_private = sqlalchemy.Column(sqlalchemy.Boolean, default=True)

    user_id = sqlalchemy.Column(sqlalchemy.Integer, 
                                sqlalchemy.ForeignKey("users.id"))
    user = orm.relation('User')
    categories = orm.relation("Category",
                          secondary="association",
                          backref="my_heroes")
