from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField
from wtforms import BooleanField, SubmitField
from wtforms.validators import DataRequired


class HeroesForm(FlaskForm):
    title = StringField('ФИО героя', validators=[DataRequired()])
    dates_of_birth = TextAreaField("Дата рождения")
    dates_of_death = TextAreaField("Дата смерти")
    place_of_birth = TextAreaField("Место рождения")
    place_of_death = TextAreaField("Место смерти")
    spouse = TextAreaField("супргу") 
    wedding = TextAreaField("дата и место бракосочетания") 
    father = TextAreaField("Отец")
    mother = TextAreaField("Мать") 
    sons = TextAreaField("Cыновья") 
    daughters = TextAreaField("Дочери") 
    brothers = TextAreaField("Братья") 
    sisters = TextAreaField("Сестры") 
    obrazavanie = TextAreaField("Образование, периоды и место обучения, названия учебного заведения") 
    work = TextAreaField("Даты и место работы, должность") 
    before_wwii = TextAreaField("жизниописание до Великой отечественной войны") 
    second_world_war = TextAreaField("время призыва на ВОВ") 
    in_wwii = TextAreaField("жизниописание во время Великой отечественной войны") 
    content = TextAreaField("жизниописание после время Великой отечественной войны")
    note_01 = TextAreaField("примечание 1")
    note_02 = TextAreaField("примечание 2")
    note_03 = TextAreaField("примечание 3")
    is_private = BooleanField("Личное")
    submit = SubmitField('Применить')